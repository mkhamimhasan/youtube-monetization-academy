import { useState } from 'react';

const WA_URL =
  'https://wa.me/1234567890?text=Hi%2C%20I%27m%20interested%20in%20your%20YouTube%20monetization%20services.';

export default function WhatsAppButton() {
  const [hovered, setHovered] = useState(false);

  return (
    <a
      href={WA_URL}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat with us on WhatsApp"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      className="fixed bottom-6 right-6 z-50 flex items-center gap-2 group focus-neon rounded-full"
    >
      {/* Tooltip label */}
      <span
        className={`
          pointer-events-none whitespace-nowrap rounded-full bg-space-panel border border-neon-whatsapp/30
          px-3 py-1.5 font-mono text-[10px] font-bold text-neon-whatsapp
          transition-all duration-200 shadow-lg
          ${hovered ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-2'}
        `}
      >
        Chat with us
      </span>

      {/* Button */}
      <span
        className="relative flex h-14 w-14 items-center justify-center rounded-full shadow-lg"
        style={{
          background: '#25d366',
          boxShadow: hovered
            ? '0 0 28px rgba(37,211,102,0.7), 0 4px 20px rgba(0,0,0,0.4)'
            : '0 0 16px rgba(37,211,102,0.4), 0 4px 14px rgba(0,0,0,0.3)',
          transition: 'box-shadow 0.25s ease',
        }}
      >
        {/* Pulse ring */}
        <span
          className="absolute inset-0 rounded-full"
          style={{
            background: 'rgba(37,211,102,0.3)',
            animation: 'whatsapp-pulse 2.2s ease-in-out infinite',
          }}
        />

        {/* WhatsApp SVG icon */}
        <svg
          viewBox="0 0 24 24"
          className="h-7 w-7 relative z-10"
          fill="white"
        >
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z" />
          <path d="M12 0C5.373 0 0 5.373 0 12c0 2.123.554 4.11 1.523 5.837L0 24l6.338-1.501A11.93 11.93 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 21.818a9.797 9.797 0 01-5.006-1.374l-.358-.213-3.763.89.952-3.665-.235-.376A9.8 9.8 0 012.182 12C2.182 6.57 6.569 2.182 12 2.182S21.818 6.57 21.818 12 17.431 21.818 12 21.818z" />
        </svg>
      </span>

      <style>{`
        @keyframes whatsapp-pulse {
          0%   { transform: scale(1);   opacity: 0.7; }
          70%  { transform: scale(1.4); opacity: 0; }
          100% { transform: scale(1.4); opacity: 0; }
        }
      `}</style>
    </a>
  );
}
